package com.attendance.dao;

import com.attendance.db.DatabaseConnection;
import com.attendance.model.Attendance;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class AttendanceDAO {
    
    public int create(Attendance attendance) throws SQLException {
        String sql = "INSERT INTO attendance (student_id, subject_id, date, status, marked_by) VALUES (?, ?, ?, ?, ?) RETURNING id";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, attendance.getStudentId());
            stmt.setInt(2, attendance.getSubjectId());
            stmt.setDate(3, attendance.getDate());
            stmt.setString(4, attendance.getStatus());
            stmt.setInt(5, attendance.getMarkedBy());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return -1;
    }
    
    public boolean markBulkAttendance(int subjectId, Date date, int markedBy, Map<Integer, String> studentStatusMap) throws SQLException {
        String deleteSql = "DELETE FROM attendance WHERE subject_id = ? AND date = ?";
        String insertSql = "INSERT INTO attendance (student_id, subject_id, date, status, marked_by) VALUES (?, ?, ?, ?, ?)";
        
        Connection conn = DatabaseConnection.getConnection();
        try {
            conn.setAutoCommit(false);
            
            try (PreparedStatement deleteStmt = conn.prepareStatement(deleteSql)) {
                deleteStmt.setInt(1, subjectId);
                deleteStmt.setDate(2, date);
                deleteStmt.executeUpdate();
            }
            
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                for (Map.Entry<Integer, String> entry : studentStatusMap.entrySet()) {
                    insertStmt.setInt(1, entry.getKey());
                    insertStmt.setInt(2, subjectId);
                    insertStmt.setDate(3, date);
                    insertStmt.setString(4, entry.getValue());
                    insertStmt.setInt(5, markedBy);
                    insertStmt.addBatch();
                }
                insertStmt.executeBatch();
            }
            
            conn.commit();
            return true;
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }
    
    public List<Attendance> findByStudentId(int studentId) throws SQLException {
        List<Attendance> attendanceList = new ArrayList<>();
        String sql = "SELECT * FROM attendance WHERE student_id = ? ORDER BY date DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                attendanceList.add(new Attendance(
                    rs.getInt("id"),
                    rs.getInt("student_id"),
                    rs.getInt("subject_id"),
                    rs.getDate("date"),
                    rs.getString("status"),
                    rs.getInt("marked_by")
                ));
            }
        }
        return attendanceList;
    }
    
    public List<Attendance> findBySubjectAndDate(int subjectId, Date date) throws SQLException {
        List<Attendance> attendanceList = new ArrayList<>();
        String sql = "SELECT * FROM attendance WHERE subject_id = ? AND date = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, subjectId);
            stmt.setDate(2, date);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                attendanceList.add(new Attendance(
                    rs.getInt("id"),
                    rs.getInt("student_id"),
                    rs.getInt("subject_id"),
                    rs.getDate("date"),
                    rs.getString("status"),
                    rs.getInt("marked_by")
                ));
            }
        }
        return attendanceList;
    }
    
    public List<Map<String, Object>> getStudentAttendanceReport(int studentId) throws SQLException {
        List<Map<String, Object>> report = new ArrayList<>();
        String sql = """
            SELECT s.id as subject_id, s.name as subject_name, s.code as subject_code,
                   COUNT(*) as total_classes,
                   SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count,
                   SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent_count
            FROM subjects s
            LEFT JOIN attendance a ON s.id = a.subject_id AND a.student_id = ?
            GROUP BY s.id, s.name, s.code
            ORDER BY s.name
        """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("subjectId", rs.getInt("subject_id"));
                row.put("subjectName", rs.getString("subject_name"));
                row.put("subjectCode", rs.getString("subject_code"));
                row.put("totalClasses", rs.getInt("total_classes"));
                row.put("presentCount", rs.getInt("present_count"));
                row.put("absentCount", rs.getInt("absent_count"));
                int total = rs.getInt("total_classes");
                int present = rs.getInt("present_count");
                double percentage = total > 0 ? (present * 100.0 / total) : 0;
                row.put("percentage", Math.round(percentage * 100.0) / 100.0);
                report.add(row);
            }
        }
        return report;
    }
    
    public List<Map<String, Object>> getAttendanceBySubjectAndDateRange(int subjectId, Date startDate, Date endDate) throws SQLException {
        List<Map<String, Object>> report = new ArrayList<>();
        String sql = """
            SELECT s.id as student_id, s.name as student_name, s.roll_number,
                   COUNT(a.id) as total_classes,
                   SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_count
            FROM students s
            LEFT JOIN attendance a ON s.id = a.student_id AND a.subject_id = ? AND a.date BETWEEN ? AND ?
            GROUP BY s.id, s.name, s.roll_number
            ORDER BY s.roll_number
        """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, subjectId);
            stmt.setDate(2, startDate);
            stmt.setDate(3, endDate);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("studentId", rs.getInt("student_id"));
                row.put("studentName", rs.getString("student_name"));
                row.put("rollNumber", rs.getString("roll_number"));
                row.put("totalClasses", rs.getInt("total_classes"));
                row.put("presentCount", rs.getInt("present_count"));
                int total = rs.getInt("total_classes");
                int present = rs.getInt("present_count");
                double percentage = total > 0 ? (present * 100.0 / total) : 0;
                row.put("percentage", Math.round(percentage * 100.0) / 100.0);
                report.add(row);
            }
        }
        return report;
    }
    
    public Map<String, Object> getOverallStats() throws SQLException {
        Map<String, Object> stats = new HashMap<>();
        String sql = """
            SELECT 
                (SELECT COUNT(*) FROM students) as total_students,
                (SELECT COUNT(*) FROM subjects) as total_subjects,
                (SELECT COUNT(*) FROM attendance) as total_records,
                (SELECT COUNT(*) FROM attendance WHERE status = 'present') as total_present
        """;
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                stats.put("totalStudents", rs.getInt("total_students"));
                stats.put("totalSubjects", rs.getInt("total_subjects"));
                stats.put("totalRecords", rs.getInt("total_records"));
                stats.put("totalPresent", rs.getInt("total_present"));
                int total = rs.getInt("total_records");
                int present = rs.getInt("total_present");
                double avgPercentage = total > 0 ? (present * 100.0 / total) : 0;
                stats.put("averageAttendance", Math.round(avgPercentage * 100.0) / 100.0);
            }
        }
        return stats;
    }
}
