package com.attendance.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
    private static Connection connection = null;
    
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            String host = System.getenv("PGHOST");
            String port = System.getenv("PGPORT");
            String database = System.getenv("PGDATABASE");
            String user = System.getenv("PGUSER");
            String password = System.getenv("PGPASSWORD");
            
            if (host == null || host.isEmpty()) {
                throw new SQLException("PGHOST environment variable not set");
            }
            if (port == null || port.isEmpty()) {
                port = "5432";
            }
            if (database == null || database.isEmpty()) {
                throw new SQLException("PGDATABASE environment variable not set");
            }
            
            String jdbcUrl = "jdbc:postgresql://" + host + ":" + port + "/" + database;
            
            Properties props = new Properties();
            if (user != null && !user.isEmpty()) {
                props.setProperty("user", user);
            }
            if (password != null && !password.isEmpty()) {
                props.setProperty("password", password);
            }
            props.setProperty("sslmode", "disable");
            
            try {
                Class.forName("org.postgresql.Driver");
                connection = DriverManager.getConnection(jdbcUrl, props);
            } catch (ClassNotFoundException e) {
                throw new SQLException("PostgreSQL JDBC Driver not found", e);
            }
        }
        return connection;
    }
    
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
