package com.attendance.server;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.attendance.dao.*;
import com.attendance.model.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ApiHandler implements HttpHandler {
    private UserDAO userDAO = new UserDAO();
    private StudentDAO studentDAO = new StudentDAO();
    private SubjectDAO subjectDAO = new SubjectDAO();
    private AttendanceDAO attendanceDAO = new AttendanceDAO();
    private Map<String, Map<String, Object>> sessions = new ConcurrentHashMap<>();
    
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        String path = exchange.getRequestURI().getPath();
        
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.getResponseHeaders().set("Cache-Control", "no-cache");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
        
        if (method.equals("OPTIONS")) {
            exchange.sendResponseHeaders(200, -1);
            return;
        }
        
        String response = "";
        int statusCode = 200;
        
        try {
            if (path.equals("/api/login") && method.equals("POST")) {
                response = handleLogin(exchange);
            } else if (path.equals("/api/logout") && method.equals("POST")) {
                response = handleLogout(exchange);
            } else if (path.equals("/api/session") && method.equals("GET")) {
                response = handleGetSession(exchange);
            } else if (path.equals("/api/students") && method.equals("GET")) {
                response = handleGetStudents(exchange);
            } else if (path.equals("/api/students") && method.equals("POST")) {
                response = handleCreateStudent(exchange);
            } else if (path.startsWith("/api/students/") && method.equals("DELETE")) {
                response = handleDeleteStudent(exchange, path);
            } else if (path.equals("/api/subjects") && method.equals("GET")) {
                response = handleGetSubjects(exchange);
            } else if (path.equals("/api/subjects") && method.equals("POST")) {
                response = handleCreateSubject(exchange);
            } else if (path.startsWith("/api/subjects/") && method.equals("DELETE")) {
                response = handleDeleteSubject(exchange, path);
            } else if (path.equals("/api/attendance/mark") && method.equals("POST")) {
                response = handleMarkAttendance(exchange);
            } else if (path.equals("/api/attendance/report") && method.equals("GET")) {
                response = handleGetAttendanceReport(exchange);
            } else if (path.equals("/api/attendance/student") && method.equals("GET")) {
                response = handleGetStudentAttendance(exchange);
            } else if (path.equals("/api/stats") && method.equals("GET")) {
                response = handleGetStats(exchange);
            } else if (path.equals("/api/attendance/check") && method.equals("GET")) {
                response = handleCheckAttendance(exchange);
            } else {
                response = "{\"error\": \"Not Found\"}";
                statusCode = 404;
            }
        } catch (SQLException e) {
            response = "{\"error\": \"Database error: " + escapeJson(e.getMessage()) + "\"}";
            statusCode = 500;
            e.printStackTrace();
        } catch (Exception e) {
            response = "{\"error\": \"" + escapeJson(e.getMessage()) + "\"}";
            statusCode = 500;
            e.printStackTrace();
        }
        
        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
    
    private String handleLogin(HttpExchange exchange) throws IOException, SQLException {
        Map<String, String> params = parseJsonBody(exchange);
        String username = params.get("username");
        String password = params.get("password");
        
        User user = userDAO.authenticate(username, password);
        if (user != null) {
            String sessionId = UUID.randomUUID().toString();
            Map<String, Object> sessionData = new HashMap<>();
            sessionData.put("userId", user.getId());
            sessionData.put("username", user.getUsername());
            sessionData.put("role", user.getRole());
            sessionData.put("name", user.getName());
            
            if (user.getRole().equals("student")) {
                Student student = studentDAO.findByUserId(user.getId());
                if (student != null) {
                    sessionData.put("studentId", student.getId());
                    sessionData.put("rollNumber", student.getRollNumber());
                    sessionData.put("className", student.getClassName());
                }
            }
            
            sessions.put(sessionId, sessionData);
            
            return "{\"success\": true, \"sessionId\": \"" + sessionId + "\", \"user\": " + userToJson(user, sessionData) + "}";
        }
        return "{\"success\": false, \"error\": \"Invalid credentials\"}";
    }
    
    private String handleLogout(HttpExchange exchange) {
        String sessionId = getSessionId(exchange);
        if (sessionId != null) {
            sessions.remove(sessionId);
        }
        return "{\"success\": true}";
    }
    
    private String handleGetSession(HttpExchange exchange) throws SQLException {
        String sessionId = getSessionId(exchange);
        if (sessionId != null && sessions.containsKey(sessionId)) {
            Map<String, Object> session = sessions.get(sessionId);
            int userId = (Integer) session.get("userId");
            User user = userDAO.findById(userId);
            if (user != null) {
                return "{\"loggedIn\": true, \"user\": " + userToJson(user, session) + "}";
            }
        }
        return "{\"loggedIn\": false}";
    }
    
    private String handleGetStudents(HttpExchange exchange) throws SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        List<Student> students = studentDAO.findAll();
        return studentsToJson(students);
    }
    
    private String handleCreateStudent(HttpExchange exchange) throws IOException, SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        Map<String, String> params = parseJsonBody(exchange);
        
        User user = new User();
        user.setUsername(params.get("rollNumber"));
        user.setPassword(params.get("password") != null ? params.get("password") : params.get("rollNumber"));
        user.setRole("student");
        user.setName(params.get("name"));
        user.setEmail(params.get("email"));
        int userId = userDAO.create(user);
        
        Student student = new Student();
        student.setRollNumber(params.get("rollNumber"));
        student.setName(params.get("name"));
        student.setEmail(params.get("email"));
        student.setClassName(params.get("className"));
        student.setUserId(userId);
        int studentId = studentDAO.create(student);
        
        return "{\"success\": true, \"id\": " + studentId + "}";
    }
    
    private String handleDeleteStudent(HttpExchange exchange, String path) throws SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        int id = Integer.parseInt(path.substring("/api/students/".length()));
        boolean deleted = studentDAO.delete(id);
        return "{\"success\": " + deleted + "}";
    }
    
    private String handleGetSubjects(HttpExchange exchange) throws SQLException {
        List<Subject> subjects = subjectDAO.findAll();
        return subjectsToJson(subjects);
    }
    
    private String handleCreateSubject(HttpExchange exchange) throws IOException, SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        Map<String, String> params = parseJsonBody(exchange);
        Map<String, Object> session = getSession(exchange);
        
        Subject subject = new Subject();
        subject.setCode(params.get("code"));
        subject.setName(params.get("name"));
        subject.setTeacherId((Integer) session.get("userId"));
        int id = subjectDAO.create(subject);
        
        return "{\"success\": true, \"id\": " + id + "}";
    }
    
    private String handleDeleteSubject(HttpExchange exchange, String path) throws SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        int id = Integer.parseInt(path.substring("/api/subjects/".length()));
        boolean deleted = subjectDAO.delete(id);
        return "{\"success\": " + deleted + "}";
    }
    
    private String handleMarkAttendance(HttpExchange exchange) throws IOException, SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        Map<String, Object> session = getSession(exchange);
        String body = readBody(exchange);
        
        int subjectId = 0;
        String dateStr = "";
        Map<Integer, String> attendanceMap = new HashMap<>();
        
        String[] parts = body.replace("{", "").replace("}", "").split(",");
        for (String part : parts) {
            String[] kv = part.split(":");
            if (kv.length == 2) {
                String key = kv[0].trim().replace("\"", "");
                String value = kv[1].trim().replace("\"", "");
                if (key.equals("subjectId")) {
                    subjectId = Integer.parseInt(value);
                } else if (key.equals("date")) {
                    dateStr = value;
                } else if (key.startsWith("student_")) {
                    int studentId = Integer.parseInt(key.substring(8));
                    attendanceMap.put(studentId, value);
                }
            }
        }
        
        Date date = Date.valueOf(dateStr);
        int markedBy = (Integer) session.get("userId");
        attendanceDAO.markBulkAttendance(subjectId, date, markedBy, attendanceMap);
        
        return "{\"success\": true}";
    }
    
    private String handleCheckAttendance(HttpExchange exchange) throws SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        String query = exchange.getRequestURI().getQuery();
        Map<String, String> params = parseQuery(query);
        int subjectId = Integer.parseInt(params.get("subjectId"));
        Date date = Date.valueOf(params.get("date"));
        
        List<Attendance> attendanceList = attendanceDAO.findBySubjectAndDate(subjectId, date);
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < attendanceList.size(); i++) {
            Attendance a = attendanceList.get(i);
            if (i > 0) sb.append(",");
            sb.append("{\"studentId\":").append(a.getStudentId())
              .append(",\"status\":\"").append(a.getStatus()).append("\"}");
        }
        sb.append("]");
        return sb.toString();
    }
    
    private String handleGetAttendanceReport(HttpExchange exchange) throws SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        String query = exchange.getRequestURI().getQuery();
        Map<String, String> params = parseQuery(query);
        
        int subjectId = Integer.parseInt(params.get("subjectId"));
        Date startDate = Date.valueOf(params.get("startDate"));
        Date endDate = Date.valueOf(params.get("endDate"));
        
        List<Map<String, Object>> report = attendanceDAO.getAttendanceBySubjectAndDateRange(subjectId, startDate, endDate);
        return listOfMapsToJson(report);
    }
    
    private String handleGetStudentAttendance(HttpExchange exchange) throws SQLException {
        String sessionId = getSessionId(exchange);
        if (sessionId == null || !sessions.containsKey(sessionId)) {
            return "{\"error\": \"Unauthorized\"}";
        }
        Map<String, Object> session = sessions.get(sessionId);
        
        int studentId;
        String query = exchange.getRequestURI().getQuery();
        if (query != null && query.contains("studentId")) {
            Map<String, String> params = parseQuery(query);
            studentId = Integer.parseInt(params.get("studentId"));
        } else {
            if (!session.containsKey("studentId")) {
                return "{\"error\": \"No student ID found\"}";
            }
            studentId = (Integer) session.get("studentId");
        }
        
        List<Map<String, Object>> report = attendanceDAO.getStudentAttendanceReport(studentId);
        return listOfMapsToJson(report);
    }
    
    private String handleGetStats(HttpExchange exchange) throws SQLException {
        if (!isAuthorized(exchange, "admin", "teacher")) {
            return "{\"error\": \"Unauthorized\"}";
        }
        Map<String, Object> stats = attendanceDAO.getOverallStats();
        return mapToJson(stats);
    }
    
    private String getSessionId(HttpExchange exchange) {
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        if (auth != null && auth.startsWith("Bearer ")) {
            return auth.substring(7);
        }
        return null;
    }
    
    private Map<String, Object> getSession(HttpExchange exchange) {
        String sessionId = getSessionId(exchange);
        if (sessionId != null) {
            return sessions.get(sessionId);
        }
        return null;
    }
    
    private boolean isAuthorized(HttpExchange exchange, String... roles) {
        Map<String, Object> session = getSession(exchange);
        if (session == null) return false;
        String userRole = (String) session.get("role");
        for (String role : roles) {
            if (role.equals(userRole)) return true;
        }
        return false;
    }
    
    private Map<String, String> parseJsonBody(HttpExchange exchange) throws IOException {
        String body = readBody(exchange);
        Map<String, String> result = new HashMap<>();
        body = body.trim();
        if (body.startsWith("{")) body = body.substring(1);
        if (body.endsWith("}")) body = body.substring(0, body.length() - 1);
        
        String[] pairs = body.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
        for (String pair : pairs) {
            int colonIndex = pair.indexOf(':');
            if (colonIndex > 0) {
                String key = pair.substring(0, colonIndex).trim().replace("\"", "");
                String value = pair.substring(colonIndex + 1).trim().replace("\"", "");
                result.put(key, value);
            }
        }
        return result;
    }
    
    private String readBody(HttpExchange exchange) throws IOException {
        try (InputStream is = exchange.getRequestBody();
             BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            return sb.toString();
        }
    }
    
    private Map<String, String> parseQuery(String query) {
        Map<String, String> result = new HashMap<>();
        if (query != null) {
            for (String param : query.split("&")) {
                String[] pair = param.split("=");
                if (pair.length == 2) {
                    result.put(pair[0], pair[1]);
                }
            }
        }
        return result;
    }
    
    private String userToJson(User user, Map<String, Object> session) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"id\":").append(user.getId());
        sb.append(",\"username\":\"").append(escapeJson(user.getUsername())).append("\"");
        sb.append(",\"role\":\"").append(escapeJson(user.getRole())).append("\"");
        sb.append(",\"name\":\"").append(escapeJson(user.getName())).append("\"");
        sb.append(",\"email\":\"").append(escapeJson(user.getEmail() != null ? user.getEmail() : "")).append("\"");
        if (session != null && session.containsKey("studentId")) {
            sb.append(",\"studentId\":").append(session.get("studentId"));
            sb.append(",\"rollNumber\":\"").append(escapeJson((String)session.get("rollNumber"))).append("\"");
            sb.append(",\"className\":\"").append(escapeJson((String)session.get("className"))).append("\"");
        }
        sb.append("}");
        return sb.toString();
    }
    
    private String studentsToJson(List<Student> students) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < students.size(); i++) {
            if (i > 0) sb.append(",");
            Student s = students.get(i);
            sb.append("{\"id\":").append(s.getId());
            sb.append(",\"rollNumber\":\"").append(escapeJson(s.getRollNumber())).append("\"");
            sb.append(",\"name\":\"").append(escapeJson(s.getName())).append("\"");
            sb.append(",\"email\":\"").append(escapeJson(s.getEmail() != null ? s.getEmail() : "")).append("\"");
            sb.append(",\"className\":\"").append(escapeJson(s.getClassName())).append("\"}");
        }
        sb.append("]");
        return sb.toString();
    }
    
    private String subjectsToJson(List<Subject> subjects) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < subjects.size(); i++) {
            if (i > 0) sb.append(",");
            Subject s = subjects.get(i);
            sb.append("{\"id\":").append(s.getId());
            sb.append(",\"code\":\"").append(escapeJson(s.getCode())).append("\"");
            sb.append(",\"name\":\"").append(escapeJson(s.getName())).append("\"}");
        }
        sb.append("]");
        return sb.toString();
    }
    
    private String listOfMapsToJson(List<Map<String, Object>> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(mapToJson(list.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }
    
    private String mapToJson(Map<String, Object> map) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!first) sb.append(",");
            first = false;
            sb.append("\"").append(entry.getKey()).append("\":");
            Object value = entry.getValue();
            if (value instanceof String) {
                sb.append("\"").append(escapeJson((String) value)).append("\"");
            } else if (value instanceof Number) {
                sb.append(value);
            } else {
                sb.append("\"").append(escapeJson(String.valueOf(value))).append("\"");
            }
        }
        sb.append("}");
        return sb.toString();
    }
    
    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
