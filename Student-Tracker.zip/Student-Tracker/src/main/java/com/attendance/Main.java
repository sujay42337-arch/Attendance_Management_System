package com.attendance;

import com.attendance.db.DatabaseConnection;
import com.attendance.server.HttpServer;
import java.sql.*;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Initializing database...");
            initializeDatabase();
            System.out.println("Database initialized successfully!");
            
            int port = 5000;
            HttpServer server = new HttpServer(port);
            server.start();
            System.out.println("Attendance Management System running at http://0.0.0.0:" + port);
            
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("Shutting down server...");
                server.stop();
                DatabaseConnection.closeConnection();
            }));
            
        } catch (Exception e) {
            System.err.println("Failed to start application: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private static void initializeDatabase() throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        Statement stmt = conn.createStatement();
        
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'teacher', 'student')),
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """);
        
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id SERIAL PRIMARY KEY,
                roll_number VARCHAR(20) UNIQUE NOT NULL,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100),
                class_name VARCHAR(50) NOT NULL,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """);
        
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS subjects (
                id SERIAL PRIMARY KEY,
                code VARCHAR(20) UNIQUE NOT NULL,
                name VARCHAR(100) NOT NULL,
                teacher_id INTEGER REFERENCES users(id),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """);
        
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id SERIAL PRIMARY KEY,
                student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
                subject_id INTEGER REFERENCES subjects(id) ON DELETE CASCADE,
                date DATE NOT NULL,
                status VARCHAR(10) NOT NULL CHECK (status IN ('present', 'absent', 'late')),
                marked_by INTEGER REFERENCES users(id),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(student_id, subject_id, date)
            )
        """);
        
        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users WHERE role = 'admin'");
        rs.next();
        if (rs.getInt(1) == 0) {
            stmt.execute("""
                INSERT INTO users (username, password, role, name, email) 
                VALUES ('admin', 'admin123', 'admin', 'Administrator', 'admin@school.edu')
            """);
            System.out.println("Default admin user created (username: admin, password: admin123)");
        }
        
        rs = stmt.executeQuery("SELECT COUNT(*) FROM users WHERE role = 'teacher'");
        rs.next();
        if (rs.getInt(1) == 0) {
            stmt.execute("""
                INSERT INTO users (username, password, role, name, email) 
                VALUES ('teacher', 'teacher123', 'teacher', 'John Smith', 'teacher@school.edu')
            """);
            System.out.println("Default teacher user created (username: teacher, password: teacher123)");
        }
        
        stmt.close();
    }
}
