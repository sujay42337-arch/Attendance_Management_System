# Attendance Management System

## Overview
A Java-based Attendance Management System using JDBC and PostgreSQL for educational institutions. The system provides secure login access for two types of users: Admin/Teacher and Student. 

**Current State:** Fully functional MVP with all core features implemented.

## Features

### Admin/Teacher Features
- Dashboard with attendance statistics
- Add and manage student records
- Create and manage subjects
- Mark daily attendance for any subject
- Generate attendance reports with date range filtering

### Student Features
- View personal attendance records
- See attendance percentage by subject
- View overall attendance summary

## Default Login Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | admin | admin123 |
| Teacher | teacher | teacher123 |

Students can log in using their roll number as username (password is also the roll number by default).

## Technology Stack

- **Backend:** Java with built-in HttpServer
- **Database:** PostgreSQL with JDBC connectivity
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Build Tool:** Maven

## Project Structure

```
├── src/main/java/com/attendance/
│   ├── Main.java                  # Application entry point
│   ├── db/
│   │   └── DatabaseConnection.java # Database connectivity
│   ├── model/
│   │   ├── User.java
│   │   ├── Student.java
│   │   ├── Subject.java
│   │   └── Attendance.java
│   ├── dao/
│   │   ├── UserDAO.java
│   │   ├── StudentDAO.java
│   │   ├── SubjectDAO.java
│   │   └── AttendanceDAO.java
│   └── server/
│       ├── HttpServer.java         # HTTP server
│       └── ApiHandler.java         # REST API endpoints
├── public/
│   ├── index.html                  # Frontend entry
│   ├── styles.css                  # Styling
│   └── app.js                      # Frontend logic
├── pom.xml                         # Maven configuration
└── replit.md                       # This file
```

## Database Schema

### Tables
- **users** - Stores login credentials (admin, teacher, student roles)
- **students** - Student information linked to users
- **subjects** - Subject/course information
- **attendance** - Attendance records with date, status, and student/subject links

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/login | User authentication |
| POST | /api/logout | End session |
| GET | /api/session | Check current session |
| GET | /api/students | List all students |
| POST | /api/students | Add new student |
| DELETE | /api/students/:id | Delete student |
| GET | /api/subjects | List all subjects |
| POST | /api/subjects | Add new subject |
| DELETE | /api/subjects/:id | Delete subject |
| POST | /api/attendance/mark | Mark attendance |
| GET | /api/attendance/check | Get existing attendance for date |
| GET | /api/attendance/report | Generate attendance report |
| GET | /api/attendance/student | Get student's attendance |
| GET | /api/stats | Get dashboard statistics |

## Building & Running

The application is automatically built and run using Maven:

```bash
mvn clean package
java -jar target/attendance-management-system-1.0-SNAPSHOT.jar
```

The server runs on port 5000.

## Recent Changes
- December 17, 2025: Initial implementation with all core MVP features

## Future Enhancements
- Add attendance statistics dashboard with charts
- Implement bulk attendance marking for entire class
- Add email notifications for low attendance warnings
- Create Excel/PDF export functionality
- Implement attendance edit/correction with audit logs
