const API_BASE = '/api';
let sessionId = localStorage.getItem('sessionId');
let currentUser = null;

document.addEventListener('DOMContentLoaded', function() {
    checkSession();
    setupEventListeners();
    setDefaultDates();
});

function setDefaultDates() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('att-date').value = today;
    document.getElementById('report-end').value = today;
    
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    document.getElementById('report-start').value = thirtyDaysAgo.toISOString().split('T')[0];
}

async function apiCall(endpoint, options = {}) {
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    if (sessionId) {
        headers['Authorization'] = `Bearer ${sessionId}`;
    }
    
    const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers
    });
    
    return response.json();
}

async function checkSession() {
    if (sessionId) {
        const data = await apiCall('/session');
        if (data.loggedIn) {
            currentUser = data.user;
            showDashboard();
        } else {
            sessionId = null;
            localStorage.removeItem('sessionId');
            showLogin();
        }
    } else {
        showLogin();
    }
}

function setupEventListeners() {
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    document.getElementById('admin-logout').addEventListener('click', handleLogout);
    document.getElementById('student-logout').addEventListener('click', handleLogout);
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });
    
    document.getElementById('add-student-btn').addEventListener('click', showAddStudentModal);
    document.getElementById('add-subject-btn').addEventListener('click', showAddSubjectModal);
    document.getElementById('load-students-btn').addEventListener('click', loadStudentsForAttendance);
    document.getElementById('save-attendance-btn').addEventListener('click', saveAttendance);
    document.getElementById('generate-report-btn').addEventListener('click', generateReport);
    
    document.querySelector('.modal-close').addEventListener('click', closeModal);
    document.getElementById('modal').addEventListener('click', (e) => {
        if (e.target.id === 'modal') closeModal();
    });
}

async function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('login-error');
    
    try {
        const data = await apiCall('/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
        
        if (data.success) {
            sessionId = data.sessionId;
            localStorage.setItem('sessionId', sessionId);
            currentUser = data.user;
            showDashboard();
            errorDiv.textContent = '';
        } else {
            errorDiv.textContent = data.error || 'Invalid credentials';
        }
    } catch (error) {
        errorDiv.textContent = 'Connection error. Please try again.';
    }
}

async function handleLogout() {
    await apiCall('/logout', { method: 'POST' });
    sessionId = null;
    localStorage.removeItem('sessionId');
    currentUser = null;
    showLogin();
}

function showLogin() {
    document.getElementById('login-page').classList.add('active');
    document.getElementById('admin-page').classList.remove('active');
    document.getElementById('student-page').classList.remove('active');
}

function showDashboard() {
    document.getElementById('login-page').classList.remove('active');
    
    if (currentUser.role === 'student') {
        document.getElementById('student-page').classList.add('active');
        document.getElementById('admin-page').classList.remove('active');
        document.getElementById('student-user-name').textContent = currentUser.name;
        document.getElementById('student-name').textContent = currentUser.name;
        document.getElementById('student-roll').textContent = currentUser.rollNumber;
        document.getElementById('student-class').textContent = currentUser.className;
        loadStudentAttendance();
    } else {
        document.getElementById('admin-page').classList.add('active');
        document.getElementById('student-page').classList.remove('active');
        document.getElementById('admin-user-name').textContent = currentUser.name;
        loadDashboardData();
        loadSubjectsForDropdowns();
    }
}

function switchTab(tabId) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
    document.getElementById(tabId).classList.add('active');
    
    if (tabId === 'dashboard') loadDashboardData();
    if (tabId === 'students') loadStudents();
    if (tabId === 'subjects') loadSubjects();
}

async function loadDashboardData() {
    try {
        const stats = await apiCall('/stats');
        document.getElementById('stat-students').textContent = stats.totalStudents || 0;
        document.getElementById('stat-subjects').textContent = stats.totalSubjects || 0;
        document.getElementById('stat-records').textContent = stats.totalRecords || 0;
        document.getElementById('stat-percentage').textContent = (stats.averageAttendance || 0) + '%';
    } catch (error) {
        console.error('Failed to load stats:', error);
    }
}

async function loadStudents() {
    try {
        const students = await apiCall('/students');
        const tbody = document.querySelector('#students-table tbody');
        tbody.innerHTML = '';
        
        if (Array.isArray(students)) {
            students.forEach(student => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${escapeHtml(student.rollNumber)}</td>
                    <td>${escapeHtml(student.name)}</td>
                    <td>${escapeHtml(student.email || '')}</td>
                    <td>${escapeHtml(student.className)}</td>
                    <td>
                        <button class="btn btn-danger btn-sm" onclick="deleteStudent(${student.id})">Delete</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }
    } catch (error) {
        console.error('Failed to load students:', error);
    }
}

async function loadSubjects() {
    try {
        const subjects = await apiCall('/subjects');
        const tbody = document.querySelector('#subjects-table tbody');
        tbody.innerHTML = '';
        
        if (Array.isArray(subjects)) {
            subjects.forEach(subject => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${escapeHtml(subject.code)}</td>
                    <td>${escapeHtml(subject.name)}</td>
                    <td>
                        <button class="btn btn-danger btn-sm" onclick="deleteSubject(${subject.id})">Delete</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }
    } catch (error) {
        console.error('Failed to load subjects:', error);
    }
}

async function loadSubjectsForDropdowns() {
    try {
        const subjects = await apiCall('/subjects');
        const attSelect = document.getElementById('att-subject');
        const reportSelect = document.getElementById('report-subject');
        
        const options = '<option value="">Select Subject</option>' + 
            (Array.isArray(subjects) ? subjects.map(s => 
                `<option value="${s.id}">${escapeHtml(s.code)} - ${escapeHtml(s.name)}</option>`
            ).join('') : '');
        
        attSelect.innerHTML = options;
        reportSelect.innerHTML = options;
    } catch (error) {
        console.error('Failed to load subjects for dropdowns:', error);
    }
}

function showAddStudentModal() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h3>Add New Student</h3>
        <form id="add-student-form">
            <div class="form-group">
                <label for="new-roll">Roll Number</label>
                <input type="text" id="new-roll" required placeholder="e.g., STU001">
            </div>
            <div class="form-group">
                <label for="new-name">Full Name</label>
                <input type="text" id="new-name" required placeholder="Enter student name">
            </div>
            <div class="form-group">
                <label for="new-email">Email</label>
                <input type="email" id="new-email" placeholder="student@email.com">
            </div>
            <div class="form-group">
                <label for="new-class">Class</label>
                <input type="text" id="new-class" required placeholder="e.g., CS-2024">
            </div>
            <div class="form-group">
                <label for="new-password">Password</label>
                <input type="password" id="new-password" placeholder="Leave blank to use roll number">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Add Student</button>
        </form>
    `;
    
    document.getElementById('add-student-form').addEventListener('submit', addStudent);
    document.getElementById('modal').classList.add('active');
}

async function addStudent(e) {
    e.preventDefault();
    
    const data = {
        rollNumber: document.getElementById('new-roll').value,
        name: document.getElementById('new-name').value,
        email: document.getElementById('new-email').value,
        className: document.getElementById('new-class').value,
        password: document.getElementById('new-password').value || document.getElementById('new-roll').value
    };
    
    try {
        const result = await apiCall('/students', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        
        if (result.success) {
            closeModal();
            loadStudents();
            loadDashboardData();
        } else {
            alert(result.error || 'Failed to add student');
        }
    } catch (error) {
        alert('Error adding student');
    }
}

async function deleteStudent(id) {
    if (!confirm('Are you sure you want to delete this student?')) return;
    
    try {
        const result = await apiCall(`/students/${id}`, { method: 'DELETE' });
        if (result.success) {
            loadStudents();
            loadDashboardData();
        }
    } catch (error) {
        alert('Error deleting student');
    }
}

function showAddSubjectModal() {
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <h3>Add New Subject</h3>
        <form id="add-subject-form">
            <div class="form-group">
                <label for="new-code">Subject Code</label>
                <input type="text" id="new-code" required placeholder="e.g., CS101">
            </div>
            <div class="form-group">
                <label for="new-subject-name">Subject Name</label>
                <input type="text" id="new-subject-name" required placeholder="e.g., Introduction to Programming">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Add Subject</button>
        </form>
    `;
    
    document.getElementById('add-subject-form').addEventListener('submit', addSubject);
    document.getElementById('modal').classList.add('active');
}

async function addSubject(e) {
    e.preventDefault();
    
    const data = {
        code: document.getElementById('new-code').value,
        name: document.getElementById('new-subject-name').value
    };
    
    try {
        const result = await apiCall('/subjects', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        
        if (result.success) {
            closeModal();
            loadSubjects();
            loadSubjectsForDropdowns();
            loadDashboardData();
        } else {
            alert(result.error || 'Failed to add subject');
        }
    } catch (error) {
        alert('Error adding subject');
    }
}

async function deleteSubject(id) {
    if (!confirm('Are you sure you want to delete this subject?')) return;
    
    try {
        const result = await apiCall(`/subjects/${id}`, { method: 'DELETE' });
        if (result.success) {
            loadSubjects();
            loadSubjectsForDropdowns();
            loadDashboardData();
        }
    } catch (error) {
        alert('Error deleting subject');
    }
}

async function loadStudentsForAttendance() {
    const subjectId = document.getElementById('att-subject').value;
    const date = document.getElementById('att-date').value;
    
    if (!subjectId || !date) {
        alert('Please select subject and date');
        return;
    }
    
    try {
        const students = await apiCall('/students');
        const existing = await apiCall(`/attendance/check?subjectId=${subjectId}&date=${date}`);
        
        const existingMap = {};
        if (Array.isArray(existing)) {
            existing.forEach(a => existingMap[a.studentId] = a.status);
        }
        
        const container = document.getElementById('attendance-list');
        container.innerHTML = '';
        
        if (Array.isArray(students) && students.length > 0) {
            students.forEach(student => {
                const status = existingMap[student.id] || 'present';
                const div = document.createElement('div');
                div.className = 'attendance-item';
                div.innerHTML = `
                    <div class="student-info">
                        <strong>${escapeHtml(student.rollNumber)}</strong> - ${escapeHtml(student.name)}
                    </div>
                    <div class="attendance-status">
                        <label class="present">
                            <input type="radio" name="att-${student.id}" value="present" ${status === 'present' ? 'checked' : ''}>
                            <span>Present</span>
                        </label>
                        <label class="absent">
                            <input type="radio" name="att-${student.id}" value="absent" ${status === 'absent' ? 'checked' : ''}>
                            <span>Absent</span>
                        </label>
                    </div>
                `;
                container.appendChild(div);
            });
            
            document.getElementById('save-attendance-btn').style.display = 'block';
        } else {
            container.innerHTML = '<p>No students found. Please add students first.</p>';
            document.getElementById('save-attendance-btn').style.display = 'none';
        }
    } catch (error) {
        console.error('Failed to load students for attendance:', error);
        alert('Error loading students');
    }
}

async function saveAttendance() {
    const subjectId = document.getElementById('att-subject').value;
    const date = document.getElementById('att-date').value;
    
    const data = {
        subjectId: parseInt(subjectId),
        date: date
    };
    
    document.querySelectorAll('.attendance-item input[type="radio"]:checked').forEach(input => {
        const name = input.name;
        const studentId = name.replace('att-', '');
        data['student_' + studentId] = input.value;
    });
    
    try {
        const result = await apiCall('/attendance/mark', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        
        if (result.success) {
            alert('Attendance saved successfully!');
            loadDashboardData();
        } else {
            alert(result.error || 'Failed to save attendance');
        }
    } catch (error) {
        alert('Error saving attendance');
    }
}

async function generateReport() {
    const subjectId = document.getElementById('report-subject').value;
    const startDate = document.getElementById('report-start').value;
    const endDate = document.getElementById('report-end').value;
    
    if (!subjectId || !startDate || !endDate) {
        alert('Please fill in all fields');
        return;
    }
    
    try {
        const report = await apiCall(`/attendance/report?subjectId=${subjectId}&startDate=${startDate}&endDate=${endDate}`);
        
        const table = document.getElementById('report-table');
        const tbody = table.querySelector('tbody');
        tbody.innerHTML = '';
        
        if (Array.isArray(report) && report.length > 0) {
            report.forEach(row => {
                const tr = document.createElement('tr');
                const percentClass = getPercentageClass(row.percentage);
                tr.innerHTML = `
                    <td>${escapeHtml(row.rollNumber || '')}</td>
                    <td>${escapeHtml(row.studentName || '')}</td>
                    <td>${row.totalClasses || 0}</td>
                    <td>${row.presentCount || 0}</td>
                    <td class="${percentClass}">${row.percentage || 0}%</td>
                `;
                tbody.appendChild(tr);
            });
            table.style.display = 'table';
        } else {
            tbody.innerHTML = '<tr><td colspan="5">No attendance records found for the selected criteria.</td></tr>';
            table.style.display = 'table';
        }
    } catch (error) {
        console.error('Failed to generate report:', error);
        alert('Error generating report');
    }
}

async function loadStudentAttendance() {
    try {
        const report = await apiCall('/attendance/student');
        
        const tbody = document.querySelector('#student-attendance-table tbody');
        tbody.innerHTML = '';
        
        let totalPresent = 0;
        let totalClasses = 0;
        
        if (Array.isArray(report) && report.length > 0) {
            report.forEach(row => {
                const tr = document.createElement('tr');
                const percentClass = getPercentageClass(row.percentage);
                tr.innerHTML = `
                    <td>${escapeHtml(row.subjectCode || '')}</td>
                    <td>${escapeHtml(row.subjectName || '')}</td>
                    <td>${row.totalClasses || 0}</td>
                    <td>${row.presentCount || 0}</td>
                    <td>${row.absentCount || 0}</td>
                    <td class="${percentClass}">${row.percentage || 0}%</td>
                `;
                tbody.appendChild(tr);
                
                totalPresent += row.presentCount || 0;
                totalClasses += row.totalClasses || 0;
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="6">No attendance records found.</td></tr>';
        }
        
        const overallPercentage = totalClasses > 0 ? Math.round((totalPresent / totalClasses) * 100) : 0;
        document.getElementById('overall-percentage').textContent = overallPercentage + '%';
    } catch (error) {
        console.error('Failed to load student attendance:', error);
    }
}

function getPercentageClass(percentage) {
    if (percentage >= 75) return 'percentage-high';
    if (percentage >= 50) return 'percentage-medium';
    return 'percentage-low';
}

function closeModal() {
    document.getElementById('modal').classList.remove('active');
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
